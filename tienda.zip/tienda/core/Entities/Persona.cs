

namespace core.Entities;

public class Persona :BaseEntityA
{
    public int IdTipoPersonaFk { get; set; }
    public TipoPersona TipoPersona { get; set; }
    public int IdRegionFk { get; set; }
    public Region Region { get; set; }
    public string Documento { get; set; } 
    public string NombrePersona { get; set; }
    public DateOnly FechaNacimiento { get; set; }

    public ICollection <Producto> Productos { get; set; }= new HashSet<Producto>();
    public ICollection <ProductoPersona> ProductoPersonas {get; set;}


}