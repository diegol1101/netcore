

using System.ComponentModel.DataAnnotations;

namespace core.Entities;

public class BaseEntityA
{
    [Key]
    public int Id { get; set; }
}