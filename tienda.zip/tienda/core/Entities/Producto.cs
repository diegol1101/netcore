

namespace core.Entities;

public class Producto :BaseEntityA
{

    public string CodigoInterno { get; set; }
    public string NombreProducto {get; set; }
    public int StockMin { get; set; }
    public int StockMax { get; set; }
    public int Stock { get; set; }
    public double ValorVta { get; set; }

    public ICollection<Persona> Personas { get; set; }
    public ICollection<ProductoPersona> ProductoPersonas { get; set; }
}