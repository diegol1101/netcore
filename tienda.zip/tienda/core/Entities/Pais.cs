


namespace core.Entities;

public class Pais : BaseEntityA
{


    public string NombrePais { get; set; }

    public ICollection <Estado> Estados { get; set; }

}