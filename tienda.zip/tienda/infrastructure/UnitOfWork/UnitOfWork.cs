using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using infraestructure.Repository;
using core.interfaces;
using infrastructure.Data;

namespace infrastructure.UnitOfWork;

public class UnitOfWork : IUnitOfWork, IDisposable
{
    private readonly tiendaAPIContext context;
    private PaisRepository _paises;

    public UnitOfWork(tiendaAPIContext _context)
    {
        context = _context;
    }
    public IPaisInterface Paises
    {
        get
        {
            if (_paises == null)
            {
                _paises = new PaisRepository(context);
            }
            return _paises;
        }
    }

    public IRegion Regiones => throw new NotImplementedException();

    public void Dispose()
    {
        context.Dispose();
    }
    public async Task<int> SaveAsync()
    {
        return await context.SaveChangesAsync();
    }


}

