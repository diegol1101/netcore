

using core.Entities;
using core.interfaces;
using infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace infraestructure.Repository
{
    public class PaisRepository : GenericRepository<Pais>, IPaisInterface
    {
        protected readonly tiendaAPIContext _context;
        public PaisRepository(tiendaAPIContext context) : base(context)
        {
            _context = context;
        }

        public override async Task<IEnumerable<Pais>> GetAllAsync()
        {
            return await _context.Paises
                .Include(p => p.Estados)
                .ToListAsync();
        }

        public override async Task<Pais> GetByIdAsync(int id)
        {
            return await _context.Paises
                .Include(p => p.Estados)
                .FirstOrDefaultAsync(p => p.Id == id);
        }
    }
}