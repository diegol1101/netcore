
using core.interfaces;
using infraestructure.Repository;
using infrastructure.UnitOfWork;

namespace tiendaAPI.Extensions;

public static class ApplicationServiceExtension
{
    public static void ConfigureCors(this IServiceCollection services) =>

        services.AddCors(options =>{

            options.AddPolicy("CorsPolicy", Builder =>
            Builder.AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader());
        });

    public static void AddAplicacionServices(this IServiceCollection services) 
    {
        services.AddScoped<IPaisInterface,PaisRepository>();
        services.AddScoped<IUnitOfWork, UnitOfWork>();
    }
}
