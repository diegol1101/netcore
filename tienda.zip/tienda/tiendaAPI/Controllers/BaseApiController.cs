
using Microsoft.AspNetCore.Mvc;

namespace tiendaAPI.Controllers;

[ApiController]
[Route("api/[controller]")]

public class BaseApiController : ControllerBase{
    
}