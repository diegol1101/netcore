

using core.Entities;
using core.interfaces;
using Microsoft.AspNetCore.Mvc;

namespace tiendaAPI.Controllers
{
    public class PaisController : BaseApiController
    {
        private readonly IUnitOfWork unitofwork;

        public PaisController(IUnitOfWork unitofwork)
        {
            this.unitofwork = unitofwork;
        }
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Pais>>> Get()
        {
            var pais = await unitofwork.Paises.GetAllAsync();
            return Ok (pais);
        }

        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult>Get(int id)
        {
            var pais = await unitofwork.Paises.GetByIdAsync(id);
            return Ok (pais);
        }
        
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Pais>> Post(Pais pais){
            unitofwork.Paises.Add(pais);
            await unitofwork.SaveAsync();
            if (pais==null)
            {
                return BadRequest();
            }
            return CreatedAtAction(nameof(Post),new {id = pais.Id}, pais);
        }
    }
}